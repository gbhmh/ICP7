const fs =  require('fs');


// ------------------Begin of Reusable functions ---------------------

var fetchNotes = () => {
    try {                          //if file won't exist
        var notesString = fs.readFileSync('notes-data.json')
        return JSON.parse(notesString);
    } catch(e){
        return [];
    }
};

var saveNotes = (notes) => {
    fs.writeFileSync('notes-data.json',JSON.stringify(notes));
};


// ------------------End of Reusable functions ---------------------


//  to add a new note

var addNote = (customer_id,customer_name,customer_email) => {
    var notes = fetchNotes();
    var note = {customer_id,customer_name,customer_email}

    var duplicateNotes =  notes.filter((note) => { // to check if note already exists
        return note.customer_id === customer_id;
    });

    if (duplicateNotes.length === 0){
        notes.push(note);
        saveNotes(notes);
        return note
    }

};


//to list all the notes

var getAll = () => {
    return fetchNotes();
};


// to read a note

var getNote = (customer_id) => {

    var notes = fetchNotes();

    var getNotes =  notes.filter((note) => {  // to check if note exists and return note
        return note.customer_id === customer_id;
    });

    return getNotes[0]

};


// to delete a note

var remove = (customer_id) => {

    var notes = fetchNotes(); // reusable func

    var filteredNotes =  notes.filter((note) => { // will return all other notes other than "note to be removed"
        return note.customer_id !== customer_id;
    });

    saveNotes(filteredNotes); //save new notes array

    return notes.length !== filteredNotes.length

};

var updateNote = (customer_id,customer_name,customer_email) => {
    var notes = fetchNotes1();
    var note = {customer_id,customer_name,customer_email}

    var duplicateNotes2 =  notes.filter((note) => { // to check if note already exists
        return note.customer_id === customer_id;
    });

    if (duplicateNotes2.length !== 0){
        notes1.push(note);
        saveNotes1(notes);
        return note
    }

};


// function just to print out note to screen

var logNote = (note) => {
    console.log('--');
    console.log(`Customer_ID: ${note.customer_id}`);
    console.log(`CustomerName: ${note.customer_name}`);
    console.log(`CustomerEmail: ${note.customer_email}`);

};

// add new function names here to be accessible from other modules

module.exports = {
    addNote, getAll, remove, getNote,logNote,updateNote
};

